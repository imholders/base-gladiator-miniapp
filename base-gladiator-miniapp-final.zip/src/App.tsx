function App() {
  return (
    <div className="container">
      <h1>Base Gladiator Arena</h1>
      <p>Daily challenge & badge fight arena</p>
      <div className="buttons">
        <a href="#" className="button">Daily Challenge</a>
        <a href="#" className="button">Submit</a>
        <a href="#" className="button">Leaderboard</a>
      </div>
    </div>
  )
}
export default App